//
//  XHTTPHeader.cpp
//  XDUILib
//
//  Created by ximiao on 16/4/23.
//  Copyright © 2016年 wudijimao. All rights reserved.
//

#include "XHTTPHeader.hpp"

const std::string XHTTPHeader::cUserAgentKey = "User-Agent";